#include<iostream>
using namespace std;
main()
{
cout<<"          888888888888     88888     88888888                      "<<endl;
cout<<"         88        88     88   88    88      88                     "<<endl;
cout<<"          8888     88    88     88   88888888                       "<<endl;
cout<<"             88    88    888888888   88      88                     "<<endl;
cout<<"    888888888888   88    88     88   88        8888888              "<<endl;
cout<<"                                                                    "<<endl;
cout<<"                                                                    "<<endl;
cout<<"        88    88     88     8888    888888     888888888            "<<endl;
cout<<"        88    88     88   88    88  88    88   88                   "<<endl;
cout<<"        88   8888    88   88    88  8888888      88888              "<<endl;
cout<<"          888     888     88888888  88     88         88            "<<endl;
cout<<"           88     88      88    88  88     888888888888             "<<endl;
}