#include<iostream>
using namespace std;
main()
{
cout<<"       +--^--------------------,--------------,---------,---------------^-,    "<<endl;
cout<<"        | |  |||||||||||||||   '----------------'       |                'o    "<<endl;
cout<<"        '+----------------------------------------------^------------------|   "<<endl;
cout<<"           '----------------,------------,-------------------------------'     "<<endl;
cout<<"            ' /XXXXXXXXX/' |            /'                                     "<<endl;
cout<<"             /XXXXXXXX/'   |           /'                                      "<<endl;
cout<<"            /XXXXXXXX/' '  -----------'                                        "<<endl;
cout<<"           /XXXXXXXX/'                                                         "<<endl;
cout<<"          /XXXXXXXX/'                                                          "<<endl;
cout<<"         (_________(                                                           "<<endl;
cout<<"          '-------'                                                            "<<endl;
}



 