#include<iostream>
using namespace std;
main()
{
system("color 7D");
cout<<"                                  oooooo       oooooo                                     "<<endl;
cout<<" ........                        o      o     o      o                ...........         "<<endl;
cout<<" .........                           ooo      o      o                ..........          "<<endl;
cout<<" ..........                       oo          o      o                .........           "<<endl;
cout<<" ...........                    oooooooo       oooooo     th          ........             "<<endl;
cout<<"   ..........           ----------------------------------------      .......              "<<endl;
cout<<"     .........            C      E     N     T     U    R     Y       ......               "<<endl;
cout<<"      .........        ----------------------------------------       .....                "<<endl;
cout<<"         .......           ooooooo  ooooooo    o     o  ooooooo       ....                 "<<endl;
cout<<"           .....              o     o           o   o      o          ...                  "<<endl;
cout<<"              ...             o     ooooo         o        o          ..                   "<<endl;
cout<<"                ..            o     o           o   o      o          ..                   "<<endl;
cout<<"             ___||___         o     ooooooo    o     o     o       ___||___                "<<endl;
cout<<"  __________|________|_____                             __________|        |_______________"<<endl;
}
                      
        
