#include<iostream>
using namespace std;
main()
{
cout<<"   -------------------------------------------------    "<<endl;
cout<<"  o      ^     ^                                        "<<endl;
cout<<"          -----                                         "<<endl;
cout<<"     o    (o o)\\____________                           "<<endl;
cout<<"          (___)\\            )\\/\\                     "<<endl;
cout<<"               ||--------W  |                           "<<endl;
cout<<"               ||           ||                          "<<endl;
}